package day13.service;

import day13.entity.Student;

import java.util.List;

public interface StudentService {
    List<Student> selectAll();
    Student selectByPid(int pid);  //先接口，后再去实现。因为有了接口，实现就可以快捷键
    int updateStudent(Student student);
    int deleteById(int pid);
    int addStudent(Student student);
}
