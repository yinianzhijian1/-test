package day13.service.ServiceImpl;

import day13.dao.StudentDao;
import day13.dao.impl.StudentDaoImpl;
import day13.entity.Student;
import day13.service.StudentService;

import java.util.List;

public class StudentServiceImpl implements StudentService {  //这两句一定记住  实现
    private StudentDao studentDao = new StudentDaoImpl();  //这句一定记住  实例后，才能使用

    public List<Student> selectAll(){
        return studentDao.selectAll();
    }

    @Override
    public Student selectByPid(int pid) {
        return studentDao.selectByPid(pid);  //对 Dao 的 ？？
    }

    @Override
    public int updateStudent(Student student) {
        return studentDao.updateStudent(student);
    }

    @Override
    public int deleteById(int pid) {
        return studentDao.deleteById(pid);
    }

    @Override
    public int addStudent(Student student) {
        return studentDao.addStudent(student);
    }

}
