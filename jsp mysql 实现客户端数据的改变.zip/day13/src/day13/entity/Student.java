package day13.entity;

import java.io.Serializable;

public class Student implements Serializable {  //这句一定记住 实现
    private int pid;        //这句一定记住 两构造 get set toString
    private int page;   // int  型 所以后面都要转型
    private String pname;

    @Override
    public String toString() {
        return "Student{" +
                "pid=" + pid +
                ", page='" + page + '\'' +
                ", pname='" + pname + '\'' +
                '}';
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public Student(int pid, int page, String pname) {
        this.pid = pid;
        this.page = page;
        this.pname = pname;
    }

    public Student() {
    }
}
