package day13.dao.impl;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import day13.dao.StudentDao;
import day13.entity.Student;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.List;

public class StudentDaoImpl implements StudentDao {   //这两句一定记住 实现
    private DataSource ds =  new ComboPooledDataSource();
    private QueryRunner qr = new QueryRunner(ds);  //这两句一定记住

    public List<Student> selectAll(){
        List<Student> studentList = null;
        try {
            String sql ="select * from test1";
            studentList = qr.query(sql,new BeanListHandler<Student>(Student.class));  //小写 query  //这两句一定记住
        } catch (Exception e) {
            e.printStackTrace();
        }
        return studentList;
    }

    public Student selectByPid(int pid){
        Student student = null;
        try {
            String sql = "select * from test1 where pid = ?";
            student = qr.query(sql,new BeanHandler<Student>(Student.class),pid);   //Student.class 是什么？
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return student;
    }

    @Override
    public int updateStudent(Student student) {
        int num = 0;

        try {
            String sql = "update test1 set pname =?,page=? where pid = ?";
            Object[] objects = {student.getPname(),student.getPage(),student.getPid()};
            num = qr.update(sql,objects);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return num;
    }

    @Override
    public int deleteById(int pid) {
        int num = 0;
        String sql = "delete from test1 where pid = ?";
        try {
            num = qr.update(sql,pid);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return num;

    }

    @Override
    public int addStudent(Student student) {
        int num = 0;
        try {
            String sql = "insert into test1(pname,page)values(?,?)";
            Object[] objects = {student.getPname(),student.getPage()};
            num = qr.update(sql,objects);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return num;
    }
}