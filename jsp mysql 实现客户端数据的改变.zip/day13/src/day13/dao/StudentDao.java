package day13.dao;

import day13.entity.Student;

import java.util.List;

public interface StudentDao {
    List<Student> selectAll();  //仅定义类型（一定记住的）
    Student selectByPid(int pid);
    int updateStudent(Student student);
    int deleteById(int pid);
    int addStudent(Student student);
}
