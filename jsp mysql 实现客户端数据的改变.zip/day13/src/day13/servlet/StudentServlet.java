package day13.servlet;

import day13.entity.Student;
import day13.service.ServiceImpl.StudentServiceImpl;
import day13.service.StudentService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

//错误：
//        update写错；未标记pid 传入值；未标记flag 改变状态；page 是int 类型；给问号赋值的 student.getPage() 顺序错误；

@WebServlet(name = "studentServlet",urlPatterns = "/studentServlet")
public class StudentServlet extends HttpServlet {
    private StudentService studentService ;

    @Override
    public void init() throws ServletException {
        studentService = new StudentServiceImpl();  //接口
    }

    @Override  //增加修改id功能
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=UTF-8");
        String flag = req.getParameter("flag");
        //查找
        if ("goUpdate".equals(flag)){
            String pidStr = req.getParameter("pid");
            Student student = studentService.selectByPid(Integer.parseInt(pidStr));
            req.setAttribute("student",student);
            req.getRequestDispatcher("update.jsp").forward(req,resp);

            //修改
        }else if("update".equals(flag)){
            //获取前端传递的参数
            String pid = req.getParameter("pid");
            String pname = req.getParameter("pname");
            String page = req.getParameter("page");
            //调用service 层 的方法
            Student student  = new Student(Integer.parseInt(pid),Integer.parseInt(page),pname);
            int num =  studentService.updateStudent(student);
            //成功
            if(num>0){
                //跳转回首页
                resp.sendRedirect("index.jsp");
            }else{
                //重定向来传递参数

                resp.sendRedirect("studentServlet?flag=goUpdate&pid="+pid);
            }
//            删除
        }else if ("delete".equals(flag)){
            String pidStr = req.getParameter("pid");  //获取前端传递的参数
            int num = studentService.deleteById(Integer.parseInt(pidStr));  //调用 service 方法
            resp.sendRedirect("index.jsp");  //删除成功，跳转到首页

//          增加页面
        }else if("goAdd".equals(flag)){
            req.getRequestDispatcher("add.jsp").forward(req,resp);
//            增加功能
        }else if("add".equals(flag)){
            String pname = req.getParameter("pname");
            int page = Integer.parseInt(req.getParameter("page"));

            Student student = new Student();
            student.setPname(pname);
            student.setPage(page);  //干啥的？
            int num = studentService.addStudent(student);
            if(num>0){
                //跳转回首页
                resp.sendRedirect("index.jsp");
            }else{
                //重定向来传递参数
                resp.sendRedirect("studentServlet?flag=goAdd");
            }
        }

        else {
                //显示
             List<Student> studentList =studentService.selectAll();
             req.setAttribute("studentList",studentList);
             req.getRequestDispatcher("index.jsp").forward(req,resp);
        }
    }

}

