package sim.dao;

import sim.entity.Student;

import java.util.List;

public interface StudentDao {
    //查询出当前页的集合
    List<Student> selectAll(Integer curentPageNo,Integer pageSize);  //一个u
    //查询总记录数
    Integer selectCount();
}
