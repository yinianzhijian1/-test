package sim.dao.StudentDaoImpl;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import sim.dao.StudentDao;
import sim.entity.Student;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.List;

public class StudentDaoImpl implements StudentDao {
    private DataSource ds = new ComboPooledDataSource();
    private QueryRunner qr = new QueryRunner(ds);  // 必有的两句

    @Override
    public List<Student> selectAll(Integer currentPageNo, Integer pageSize) {
        List<Student>  studentList = null;
        try {
            String sql  ="select *  from  user  limit ?,?";
            Object[] objects={(currentPageNo-1)*pageSize,pageSize};  //页面数量，页面大小
            studentList = qr.query(sql,new BeanListHandler<Student>(Student.class),objects);  //很多地方少写了 r currentPageNo
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return studentList;
    }


    @Override
    public Integer selectCount() {
        Long count = null;
        try {
            String sql ="select count(1) from  user";   //把 Long 写成 long
            count = (Long) qr.query(sql,new ScalarHandler());  //总页数
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Integer.parseInt(count+"");
    }
}
