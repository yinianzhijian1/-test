package sim.entity;

import java.io.Serializable;

public class Student implements Serializable {
    private  int uid;
    private  String uname;
    private String uage;

    @Override
    public String toString() {
        return "Student{" +
                "uid=" + uid +
                ", uname='" + uname + '\'' +
                ", uage='" + uage + '\'' +
                '}';
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUage() {
        return uage;
    }

    public void setUage(String uage) {
        this.uage = uage;
    }


    public Student() {
    }


    public Student(int uid, String uname, String uage) {
        this.uid = uid;
        this.uname = uname;
        this.uage = uage;
    }
}
