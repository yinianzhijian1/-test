package sim.Utils;

import java.util.List;

public class PageUtils<T> {
    //当前页
    private int currentPageNo;
    //页量
    private int pageSize;

    //总记录数
    private int totalPageCount;

    //总页数
    private int totalPageSize;

    //当前页的集合
    private List<T> list;

    @Override
    public String toString() {
        return "PageUitls{" +
                "currentPageNo=" + currentPageNo +
                ", pageSize=" + pageSize +
                ", totalPageCount=" + totalPageCount +
                ", totalPageSize=" + totalPageSize +
                ", list=" + list +
                '}';
    }

    public int getCurrentPageNo() {
        return currentPageNo;
    }

    public void setCurrentPageNo(int currentPageNo) {
        this.currentPageNo = currentPageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPageCount() {
        return totalPageCount;
    }

    public void setTotalPageCount(int totalPageCount) {
        this.totalPageCount = totalPageCount;
    }

    public int getTotalPageSize() {
        return totalPageSize;
    }

    public void setTotalPageSize(int totalPageSize) {
        this.totalPageSize = totalPageSize;
    }

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public PageUtils() {
    }

    public PageUtils(int currentPageNo, int pageSize, int totalPageCount, int totalPageSize, List<T> list) {
        this.currentPageNo = currentPageNo;
        this.pageSize = pageSize;
        this.totalPageCount = totalPageCount;
        this.totalPageSize = totalPageSize;
        this.list = list;
    }


}
