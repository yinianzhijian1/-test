package sim.service.StudentServiceImpl;

import sim.dao.StudentDao;
import sim.dao.StudentDaoImpl.StudentDaoImpl;
import sim.entity.Student;
import sim.service.StudentService;

import java.util.List;

public class StudentServiceImpl implements StudentService {
    private StudentDao studentDao  = new StudentDaoImpl();  //必有的实例
    @Override
    public List<Student> selectAll(Integer currentPageNo, Integer pageSize) {   //
        return studentDao.selectAll(currentPageNo,pageSize);
    }

    @Override
    public Integer selectCount() {
        return studentDao.selectCount();
    }
}
