package sim.service;

import sim.entity.Student;

import java.util.List;

public interface StudentService {
    //查询出当前页的集合
    List<Student> selectAll(Integer currentPageNo,Integer pageSize);
    //查询总记录数
    Integer selectCount();
}
