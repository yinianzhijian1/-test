package sim.servlet;

import sim.Utils.PageUtils;
import sim.entity.Student;
import sim.service.StudentService;
import sim.service.StudentServiceImpl.StudentServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "studentServlet" ,urlPatterns = "/studentServlet")
public class StudentServlet extends HttpServlet {
    private StudentService studentService;  //一定有的一句

    @Override
    public void init() throws ServletException {
        studentService = new StudentServiceImpl();   //一定有的一句
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String currentPageNoStr = req.getParameter("currentPageNo");  //本页的当前页量
        Integer currentPageNo = null;
        if(currentPageNoStr ==null || currentPageNoStr==""){
            currentPageNo = 1;
        }else{
            currentPageNo =Integer.parseInt(currentPageNoStr);
        }

        String pageSizeStr = req.getParameter("pageSize");  //当前页量数
        Integer pageSize=null;
        if(pageSizeStr ==null || pageSizeStr==""){
            pageSize = 2;  //无页量，则为2
        }else{
            pageSize =Integer.parseInt(pageSizeStr);  //有页量，则传递
        }

        Integer totalPageCount = studentService.selectCount();
        Integer totalPageSize =  totalPageCount  % pageSize ==0 ? totalPageCount / pageSize  //为什么等于0————因为把 % 打成了 /
                : totalPageCount / pageSize +1;
        List<Student> studentList = studentService.selectAll(currentPageNo,pageSize);
        PageUtils<Student> pageUtils = new PageUtils<>();  //数据库的名字和实体类不同，导致错误。
        pageUtils.setCurrentPageNo(currentPageNo);
        pageUtils.setPageSize(pageSize);
        pageUtils.setTotalPageCount(totalPageCount);
        pageUtils.setTotalPageSize(totalPageSize);
        pageUtils.setList(studentList);
        req.setAttribute("pageUtils",pageUtils);
        req.getRequestDispatcher("index.jsp").forward(req,resp);
    }
}
